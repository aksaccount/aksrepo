package com.bed2;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MCQRepository extends JpaRepository<SpringMCQs, Long> {

}
