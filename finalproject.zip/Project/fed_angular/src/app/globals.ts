import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
  message : number = 0;
  messageCount: number = 0;
}