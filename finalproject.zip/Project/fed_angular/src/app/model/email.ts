export class Email {
    sendTo: string;
    subject: string;
    message: string;
}