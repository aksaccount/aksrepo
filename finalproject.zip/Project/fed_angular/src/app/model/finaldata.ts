export class FinalData {
    countAbove: number;
    countBelow: number;
    initialAverage: number;
    month1Average: number;
    month2Average: number;
    month3Average: number;
    maleCount: number;
    femaleCount:number;
}