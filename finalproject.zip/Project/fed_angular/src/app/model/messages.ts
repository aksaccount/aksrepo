export class MessageData {
    id: number;
    userId: string;
    sender: string;
    message: string;
    username: string;
    groupname: string;
    batchname: string;
}