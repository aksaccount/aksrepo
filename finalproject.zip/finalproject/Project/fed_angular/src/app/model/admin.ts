export class Admin {
    userType: string;
    userId: string;
    password: string;
    username: any;
    oldpassword: string;
    batch: string;
}