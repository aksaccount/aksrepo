export class dailyLog {
    userId: string;
    date: string;
    breakfast: string;
    lunch: string;
    dinner: string;
    fruits: string;
    vegetables: string;
    workouts: string;
}