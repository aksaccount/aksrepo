export class Monthly {
    userId: string;
    weigth: number;
    heigth: number;
    chest:  number;
    waist: number;
    shoulders: number;
    biceps: number;
    forearm: number;
    leg: number;
    thighs: number;
    month: string;
    date: string;
}