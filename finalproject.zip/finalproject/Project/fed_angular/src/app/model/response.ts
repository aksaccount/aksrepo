export class Response {
    response: string;
}